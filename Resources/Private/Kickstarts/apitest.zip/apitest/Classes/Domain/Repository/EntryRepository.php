<?php
namespace Nng\Apitest\Domain\Repository;

class EntryRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {}